﻿/*
 * @Author: liuyongqi
 * @Date: 2023-04-26 19:39:12
 * @LastEditors: liuyongqi
 * @LastEditTime: 2023-05-06 16:50:21
 * @Description: Used for RRC encode and decode test.
 */


#ifndef _RRC_ASN1_TEST_H_
#define _RRC_ASN1_TEST_H_
#include "rrc_nr_asn1_if.h"

#define _ASN1_UPGRADE_TEST_

#ifdef _ASN1_UPGRADE_TEST_

#define MAX_ENC_ARRAY_LEN 20 // define for _DECODE_RRC_MSG_IDX enum max
#define MAX_TEST_ENCODE_LENGTH 60

#define MAX_DEC_ARRAY_LEN 30
#define MAX_TEST_DECODE_LENGTH 300

// The Macro defined for RRC Encode test.
#define MAX_RRC_MSG_NAME_LEN 50 // Message name string len
#define MAX_RRC_MSG_NUM 50      // Test RRC message num.

#define RRC_ENCODE_MSG_BUFFER_MAX_SIZE 1500


typedef enum _DECODE_RRC_MSG_IDX
{
    // BCCH-BCH-Message Decode Test case Idx
    BCCH_BCH_MSG_IDX1, // 0
    BCCH_BCH_MSG_IDX2, // 1
    BCCH_BCH_MSG_IDX3, // 2
    // BCCH-DL-SCH-Message Decode Test case Idx
    BCCH_DL_SCH_MSG_SIB1, // 3
    BCCH_DL_SCH_MSG_SIB2, // 4
    BCCH_DL_SCH_MSG_SIB3, // 5
    BCCH_DL_SCH_MSG_SIB5, // 6
    BCCH_DL_SCH_MSG_SIB2_8, // 7
    // DL-CCCH-Message Decode Test case Idx
    DL_CCCH_MSG_CONN_SETUP1, // 8
    UL_CCCH_MSG_CONN_REEST_REQ1, // 9
    UL_CCCH_MSG_CONN_REEST1, // 10
    
    // DL-DCCH-Message Decode Test case Idx
    DL_DCCH_MSG_IDX1, // 11
    DL_DCCH_MSG_IDX2, // 12
    DL_DCCH_MSG_IDX3, // 13
    DL_DCCH_MSG_IDX4, // 14
    // PCCH-Message Decode Test case Idx
    PCCH_MSG_IDX1, // 15
    DL_DCCH_MSG_RRC_CONN_RECONFIG_IDX5, // 16
    BCCH_DL_SCH_SIB2_FAIL_0605, // 17 Sib decode fail at date 0605
    BCCH_DL_SCH_SIB5_FAIL_0609, // 18 SIB decode fail SIB5 0609
    BCCH_DL_SCH_SIB3_FAIL_0613, // 19 SIB3 decode fail 0613
    BCCH_DL_SCH_SIB2_FAIL_0614, // 20 SIB2 decode fail 0614
    BCCH_DL_SCH_SIB2_FAIL_0614_2, // 21 SIB2 decode fail 0614
    BCCH_DL_SCH_SIB3_FAIL_ECM9100_2924, // 22 SIB3 decode fail ECM9100-2924
    BCCH_DL_SCH_SIBX_FAIL_20240711, // 23 20240711
    DECODE_RRC_MSG_MAX // The last enum value
} DECODE_RRC_MSG_IDX;


typedef enum _DECODE_NR_RRC_MSG_IDX
{
    // BCCH-BCH-Message Decode Test case Idx
    NR_RRC_BCCH_BCH_MSG_IDX0, // 0
    NR_RRC_BCCH_BCH_MSG_IDX1, // 0
    NR_RRC_BCCH_BCH_MSG_IDX2, // 0

    // DL-SCH Message
    NR_RRC_DL_SCH_MSG_IDX1, // 1
    DECODE_NR_RRC_MSG_MAX // The last enum value
} DECODE_NR_RRC_MSG_IDX;


typedef struct _RRCChannelData
{
    U16 ucChannel;
    U16 usDataLen;
    S8 pMsgName[50];
    U8 arrEncodedRRCMsg[MAX_TEST_DECODE_LENGTH];
} RRCChannelData;


/***************************************************************
 *                RRC Encode definition
 ****************************************************************/

typedef enum _ENCODE_RRC_MSG_IDX
{
    // UL-CCCH-Message Decode Test case Idx
    UL_RRC_CONN_REQ_01 = 0,
    UL_RRC_CONN_REQ_02,
    UL_RRC_CONN_REQ_03,
    UL_RRC_CONN_REEST_REQ_01,
    // UL-DCCH-Message Decode Test case Idx
    UL_MEASUREMENT_PRT_01,
    //    UL_MEASUREMENT_PRT_2,
    //    UL_MEASUREMENT_PRT_3,
    UL_RRC_CONN_RECONF_COM_01, // RRCConnectionReconfigurationComplete
    UL_RRC_CONN_REEST_COM_01,
    UL_RRC_CONN_SETUP_COM_01, // RRCConnectionSetupComplete
    UL_SEC_MOD_COM_01,        // SecurityModeComplete
    UL_SMC_MOD_FAILURE_01,
    UL_UE_CAP_INFO_01,   // UECapabilityInformation
    UL_INFO_TRANSFER_01, // ULInformationTransfer
    UL_COUNTER_CHECK_RESP_01,
    UL_COUNTER_CHECK_RESP_02,
    UL_UE_INFO_RESP_01,
    UL_UE_INFO_RESP_02,

    /* Test DL RRC message Encode and Decode Start*/
    /* --------- PCCH --------- */
    DL_PAGING_01,
    DL_PAGING_02,
    /* --------- DL-CCCH --------- */
    DL_RRC_CONN_REEST_01,
    DL_RRC_CONN_REEST_02,

    DL_RRC_CONN_REEST_REJ_01,
    DL_RRC_CONN_REEST_REJ_02,

    DL_RRC_CONN_REJ_01,
    DL_RRC_CONN_REJ_02,

    DL_RRC_CONN_SETUP_01,
    DL_RRC_CONN_SETUP_02,

    /* --------- DL-DCCH --------- */
    DL_INFO_TRANSFER_01,
    DL_INFO_TRANSFER_02,

    DL_RRC_CONN_RECONFIG_01,
    DL_RRC_CONN_RECONFIG_02,

    DL_RRC_CONN_REL_01,
    DL_RRC_CONN_REL_02,

    DL_SEC_MOD_COM_01,
    DL_SEC_MOD_COM_02,

    DL_UE_CAP_ENQR_01,
    DL_UE_CAP_ENQR_02,

    DL_COUNTER_CHECK_01,
    DL_COUNTER_CHECK_02,

    DL_UE_INFO_REQ_01,
    DL_UE_INFO_REQ_02,
    /*Only used for construct needed message end.*/
    UL_ENCODE_MSC_MAX
} ENCODE_RRC_MSG_IDX;


typedef struct _RRCEncResult
{
    U16 usDataLen;
    U8 arrEncodedRRCMsg[MAX_TEST_ENCODE_LENGTH];
} RRCEncResult;


//void rrc_test_asn1_codec(void);

#endif // end of _ASN1_UPGRADE_TEST_
#endif
