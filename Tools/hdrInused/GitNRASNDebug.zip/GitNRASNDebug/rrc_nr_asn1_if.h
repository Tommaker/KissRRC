/*
 * @Author: liuyongqi
 * @Date: 2023-01-29 16:29:19
 * @LastEditors: liuyongqi
 * @LastEditTime: 2023-03-22 19:47:04
 * @Description: RRC Encoder and Decoder header file.
 */

#ifndef _RRC_NR_ASN1_IF_H_
#define _RRC_NR_ASN1_IF_H_

#include "asn1_common_def.h"

#include "NR-RRC-Definitions.h"

#define _ASN1_NR_SIB_DECODE_



/**
 * @description: RRC logical channel except MCCH
 */
typedef enum _NR_RRC_MSG_LGCH_TYPE_E
{
    NR_RRC_CHANNEL_START =0,
    NR_RRC_BCCH_BCH,    // 1, MIB
    NR_RRC_DL_SCH,      // 2. DL-SCH, SIB1(目前仅针对SIB1解码)
    NR_RRC_CHANNEL_END
} NR_RRC_MSG_LGCH_TYPE_E;


/**
 * @description: RRC every channel message definition with message content.
 * Only DL logical channel message.
 * Used in decoder.
 */
typedef union _NR_RRC_MSG_CONTENT
{
#ifdef _ASN1_NR_SIB_DECODE_
    // Only used in ASN1C decode and encode test.
    /*t=2*/
    NR_BCCH_BCH_MessageType_t stNRBcchBchMsg;
    /*t=4*/
    NR_BCCH_DL_SCH_MessageType_t stNRBcchDlschMsg;
#endif
}U_NR_RRC_MSG_CONTENT;

/**
 *  Define RRC Decode struct: RRC_DECODE_STRUCT_S
 */
typedef struct _NR_RRC_DECODE_STRUCT_S
{
    U8 ucType; /*RRC_MSG_LGCH_TYPE_E*/
    U_NR_RRC_MSG_CONTENT u;
} NR_RRC_DECODE_STRUCT_S;



/// Encode struct
/**
 * @description: RRC every channel message definition with pointer
 * Only UL logical channel message.
 */
typedef union _NR_RRC_MSG_POINTER
{
    /*t=1*/
    NR_BCCH_BCH_MessageType_t *pstNRBcchBchMsg;
    /*t=2*/
    NR_BCCH_DL_SCH_MessageType_t *pstNRBcchDlschMsg;
} U_NR_RRC_MSG_POINTER;



/**
 *  Define RRC Encode struct: RRC_ENCODE_STRUCT_S
 */
typedef struct _NR_RRC_ENCODE_STRUCT_S
{
    U8 ucType; /*NR_RRC_MSG_LGCH_TYPE_E*/
    U_NR_RRC_MSG_POINTER u;
} NR_RRC_ENCODE_STRUCT_S;


/**
 * @description: RRC function definition as below.
 */
//U16 rrc_nr_asn1_encode(const RRC_ENCODE_STRUCT_S *pEncodeMsg, U8 *pEncodeBuf, U16 usBufLen, U16 *usEncodedLen);
U16 rrc_nr_asn1_decode(NR_RRC_DECODE_STRUCT_S *pDecodeMsg, U8 ucMsgType, U8 *pBuf, U16 usLen);

U16 rrc_nr_asn1_encode(NR_RRC_DECODE_STRUCT_S *pEncodeMsg, U8 *pEncodeBuf, U16 usBufLen, U16 *pEncodedLen);



#endif // end of RRC_ASN1_IF_H_

