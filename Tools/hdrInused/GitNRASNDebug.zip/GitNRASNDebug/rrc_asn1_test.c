﻿#define FILE_NAME rrc_asn1_test
#define THIS_MODULE MODULE_ERRC

/*
 * @Author: liuyongqi
 * @Date: 2023-04-26 19:39:12
 * @LastEditors: liuyongqi
 * @LastEditTime: 2023-05-06 16:50:21
 * @Description: Used for RRC encode and decode test.
 */

#include <string.h>
#include <stdio.h>
#include <time.h>
#include <stdio.h>
#include "rrc_asn1_test.h"

#ifdef _ASN1_UPGRADE_TEST_
NR_RRC_DECODE_STRUCT_S g_RRCStructToBeDec;

// Use to store RRC encode result for test compare.
RRCEncResult RRCEncodeResultForCmp[MAX_RRC_MSG_NUM];


// 0. Construct RRC data buffer
RRCChannelData NR_RRCMsg2DecodeList[MAX_DEC_ARRAY_LEN] =
{
        /*********** BCCH-BCH-Message list start **********************/
        // BCCH_BCH_MSG_IDX1 // 0
        {NR_RRC_BCCH_BCH, 3, "MIB", {0x48, 0xab,0x14}},
        {NR_RRC_BCCH_BCH, 3, "MIB", {0x06, 0xab,0x14}},
        {NR_RRC_BCCH_BCH, 3, "MIB", {0x70, 0xab,0x14}},


        // BCCH_BCH_MSG_IDX2 // 1
        {NR_RRC_DL_SCH, 129, "SIB1", 
            {
                0X7c, 0X80, 0X0c, 0X0a, 0X0a, 0X30, 0X04, 0X73, 0Xea, 0X01, 0Xf3, 0Xea, 0X1c, 0Xd2, 0X02, 0X82,
                0X8c, 0X00, 0X1c, 0Xfa, 0X80, 0X7c, 0Xfa, 0X87, 0X34, 0X80, 0Xc0, 0X20, 0X22, 0X04, 0X00, 0X10,
                0X21, 0X18, 0Xc1, 0X0e, 0X68, 0Xa0, 0X80, 0X00, 0X44, 0X00, 0X00, 0X06, 0X96, 0X70, 0Xcb, 0X15,
                0Xfb, 0X13, 0Xb8, 0X20, 0X10, 0X00, 0X01, 0X11, 0X41, 0Xb9, 0X00, 0Xe9, 0X80, 0X00, 0X08, 0X8a,
                0X00, 0X08, 0X04, 0X1b, 0X04, 0X22, 0X81, 0X78, 0Xca, 0X57, 0X24, 0X8e, 0Xc5, 0Xa1, 0Xf0, 0Xa7,
                0X10, 0X04, 0Xe1, 0X00, 0X02, 0Xf5, 0Xf4, 0X00, 0X00, 0X03, 0X4e, 0Xae, 0X70, 0Xcb, 0X12, 0X80,
                0X98, 0X05, 0X26, 0X26, 0Xa3, 0Xce, 0X91, 0X8a, 0X93, 0X8c, 0X49, 0Xb8, 0X95, 0X36, 0X02, 0Xf8,
                0X37, 0X0c, 0X5d, 0X08, 0X2a, 0X6a, 0X6e, 0X62, 0X80, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00,
                0X00
            }
        },
};




int RRCNREncResultCompare(RRCChannelData *pExpectEncResult, U8 *pEncRes, U16 usEncLen)
{
    if (pExpectEncResult->usDataLen != usEncLen)
    {
        debug_printf("RRCEncResultCompare: Encode length mismatch expect len: %d, the real len: %d.\n", pExpectEncResult->usDataLen, usEncLen);
        return RRC_FALSE;
    }
    else
    {
        for (U16 uIdx = 0; uIdx < usEncLen; uIdx++)
        {
            if (pExpectEncResult->arrEncodedRRCMsg[uIdx] != pEncRes[uIdx])
            {
                debug_printf("RRCEncResultCompare: Encode mismatch at Index: %d.\n", uIdx);
                return RRC_FALSE;
            }
        }
    }
    return RRC_TRUE;
}


// NR ASN.1 test
void rrc_test_nr_asn1_codec()
{
    U8 *pEncResultBuf = (U8 *)malloc(RRC_ENCODE_MSG_BUFFER_MAX_SIZE);
	if (NULL == pEncResultBuf)
	{
		debug_printf("rrc_test_nr_asn1_codec malloc encoded buffer FAIL!!!\n");
		return;
	}

    // 1. Start Decode
    time_t CurrTime = time(NULL);
    struct tm* LocalTime = localtime(&CurrTime);
    debug_printf("\n\n\n\nStart NR Decode time: %d-%d-%d %d:%d:%d\n",
           LocalTime->tm_year + 1900,
           LocalTime->tm_mon + 1,
           LocalTime->tm_mday,
           LocalTime->tm_hour,
           LocalTime->tm_min,
           LocalTime->tm_sec);

    // Decode the RRC channel data set in RRCMsg2DecodeList
    U8 uIdx = NR_RRC_DL_SCH_MSG_IDX1;
    for (; uIdx < DECODE_NR_RRC_MSG_MAX; uIdx++)
    {
        pl_memset(&g_RRCStructToBeDec, 0, sizeof(g_RRCStructToBeDec));
        // Start Decode procedure.
        if (RRC_SUCCESS == rrc_nr_asn1_decode(&g_RRCStructToBeDec, NR_RRCMsg2DecodeList[uIdx].ucChannel , NR_RRCMsg2DecodeList[uIdx].arrEncodedRRCMsg, NR_RRCMsg2DecodeList[uIdx].usDataLen))
        {
        	debug_printf("\r\nDecode success at index:%d, Messge Name:%s\n", uIdx, NR_RRCMsg2DecodeList[uIdx].pMsgName);
        }
        else
        {
            debug_printf("Decode error at index:%d!!!!!!!!\n, Messge Name:%s\n", uIdx, NR_RRCMsg2DecodeList[uIdx].pMsgName);
        }

#if 0
        U16 usEncResultLen = 0;
		// Encode compare
		U16 EnCodeRet = rrc_nr_asn1_encode(&g_RRCStructToBeDec, pEncResultBuf , RRC_ENCODE_MSG_BUFFER_MAX_SIZE, &usEncResultLen);

		if (RRC_SUCCESS == EnCodeRet)
		{
			if (RRC_TRUE == RRCNREncResultCompare(&NR_RRCMsg2DecodeList[uIdx], pEncResultBuf, usEncResultLen))
			{
                debug_printf("Decode and encode compare success at index:%d!!!!!!!!\n, Messge Name:%s\n", uIdx, NR_RRCMsg2DecodeList[uIdx].pMsgName);
			}
            debug_printf("Decode success but encode error at index:%d!!!!!!!!\n, Messge Name:%s\n", uIdx, NR_RRCMsg2DecodeList[uIdx].pMsgName);
		}
#endif
    }

    //return;
    debug_printf("End NR Decode Test procedure!\n");
    CurrTime = time(NULL);
    LocalTime = localtime(&CurrTime);
    debug_printf("End Decode time: %d-%d-%d %d:%d:%d\n",
           LocalTime->tm_year + 1900,
           LocalTime->tm_mon + 1,
           LocalTime->tm_mday,
           LocalTime->tm_hour,
           LocalTime->tm_min,
           LocalTime->tm_sec);


	free(pEncResultBuf);
    return;
}


void main()
{
    asn1_initMemoryPool();
    //rrc_test_lte_asn1_codec();
    rrc_test_nr_asn1_codec();
}

#endif
