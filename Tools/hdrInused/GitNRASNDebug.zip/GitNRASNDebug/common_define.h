#include <stdio.h>
#include <stdlib.h>

typedef char S8;
typedef unsigned char U8;
typedef short int S16;
typedef unsigned short int U16;
typedef int S32;
typedef unsigned int U32;
typedef float F32;
typedef double D64;
typedef long long S64;
typedef unsigned long long U64;
/* Signed integer definitions (64bit, 40bit, 32bit, 16bit) follow... */
#define STATUS S32

#define pthread_t U32

/*** SHA-256 Context Structure ********** *******************************/
#define u_int64_t U64
#define u_int32_t U32

#define pl_malloc	malloc
#define pl_free		free
#define pl_memset   memset
#define pl_memcpy   memcpy

#define LOG_WARN printf
#define LOG_INFO printf
#define LOG_ERROR printf
#define debug_printf printf

#define RRC_ERR_ASN1_ERR 1
#define RRC_ERR_INPUT_PARAM_PTR_NULL 2
#define RRC_SUCCESS 0