/*
 * @Author: liuyongqi
 * @Date: 2023-05-24 19:05:20
 * @LastEditors: liuyongqi
 * @LastEditTime: 2023-05-24 20:00:26
 * @Description: This file realize the RRC ASN.1 message encode and decode function interface.
 */
#define THIS_MODULE MODULE_ERRC
#define FILE_NAME rrc_nr_asn1_if

#include "rrc_nr_asn1_if.h"
#include "asn1_common_def.h"


/**
 * @brief RRC decode interface.
 *
 * @param pDecodeMsg output the RRC message decode result struct.
 * @param ucMsgType message's channel.
 * @param pBuf RRC message BYTE original stream.
 * @param usLen RRC message BYTE original stream lengrth.
 * @return U16 RRC decode result.
 */
U16 rrc_nr_asn1_decode(NR_RRC_DECODE_STRUCT_S *pDecodeMsg, U8 ucMsgType, U8 *pBuf, U16 usLen)
{
    // input param check.
    if (NULL == pDecodeMsg || NULL == pBuf)
    {
        return RRC_ERR_INPUT_PARAM_PTR_NULL;
    }
    asn_codec_ctx_t *opt_codec_ctx = 0;
    asn_TYPE_descriptor_t *pPduTypeDescType = NULL;

    // Point to the message type to decode.
    void *pRecvMsg = NULL;
    pl_memset(pDecodeMsg, 0, sizeof(NR_RRC_DECODE_STRUCT_S));
    // Init RRC ASN1 Memory Pool
    asn1_ResetMemoryPool();

    /*依据逻辑信道类型，进行各个类型的消息解码*/
    switch (ucMsgType)
    {
    case NR_RRC_BCCH_BCH:
        pPduTypeDescType = &asn_DEF_NR_BCCH_BCH_MessageType;
        pRecvMsg = &pDecodeMsg->u.stNRBcchBchMsg;
        pl_memset(pRecvMsg, 0, sizeof(NR_BCCH_BCH_MessageType_t));
        break;
    case NR_RRC_DL_SCH:
        pPduTypeDescType = &asn_DEF_NR_BCCH_DL_SCH_MessageType;
        pRecvMsg = &pDecodeMsg->u.stNRBcchDlschMsg;
        pl_memset(pRecvMsg, 0, sizeof(NR_BCCH_DL_SCH_MessageType_t));
        break;

    default:
        LOG_WARN("RRC ASN1 Decode: unknown decode NR msg channel [%d]. Stop decode!", ucMsgType);
        return RRC_ERR_ASN1_ERR;
    }
    //g_ucRRCDecMemAllocFlag = RRC_TRUE;
    asn_dec_rval_t RetVal = uper_decode(opt_codec_ctx, pPduTypeDescType, &pRecvMsg, pBuf, usLen, 0, 0);
    // Set message channel type.
    pDecodeMsg->ucType = ucMsgType;
    // uper decode check.
    if (RC_OK != RetVal.code)
    {
        LOG_WARN("Decode NR RRC Message FAIL! Channel=%d, BYTE Stream:", ucMsgType);
    }
    else
    {
        debug_printf("Decode NR RRC Message SUCCESS! Channel:%d.\n", ucMsgType);
    }

    return RRC_SUCCESS;
}


/**
 * @brief RRC encode interface.
 *
 * @param pEncodeMsg input RRC message to be encoded.
 * @param pEncodeBuf output store RRC message encoded in bytes.
 * @param usBufLen pEncodeBuf length.
 * @param usEncodedLen output the real encoded bytes.
 * @return U16 RRC encode result.
 */
U16 rrc_nr_asn1_encode(NR_RRC_DECODE_STRUCT_S *pEncodeMsg, U8 *pEncodeBuf, U16 usBufLen, U16 *pEncodedLen)
{
    /*检查input指针参数*/
    if (NULL == pEncodeMsg || NULL == pEncodeBuf || NULL == pEncodedLen)
    {
        return RRC_ERR_INPUT_PARAM_PTR_NULL;
    }
    asn_TYPE_descriptor_t *pPduTypeDescType = NULL;
    // Point to the message type to encode.
    void *pSendMsg = NULL;

    pl_memset(pEncodeBuf, 0, usBufLen);

    /*依据逻辑信道类型，进行各个类型的消息编码*/
    switch (pEncodeMsg->ucType)
    {
    case NR_RRC_BCCH_BCH:
        pPduTypeDescType = &asn_DEF_NR_BCCH_BCH_MessageType;
        pSendMsg = (void *)(&pEncodeMsg->u.stNRBcchBchMsg);
        break;
    case NR_RRC_DL_SCH:
        pPduTypeDescType = &asn_DEF_NR_BCCH_DL_SCH_MessageType;
        pSendMsg = (void *)(&pEncodeMsg->u.stNRBcchDlschMsg);
        break;

    default:
        // Release the memory allocated in ASN.1 PER encoding.
        // other channel except UL not dispose.
        LOG_WARN("RRC ASN1 Encode: unknown encode msg channel [%d]. Stop encode!", pEncodeMsg->ucType);
        return RRC_ERR_ASN1_ERR;
    }
    //g_ucRRCEncMemAllocFlag = RRC_TRUE;
    asn_enc_rval_t RetVal = uper_encode_to_buffer(pPduTypeDescType, pSendMsg, (void *)pEncodeBuf, usBufLen);
    // ASN_STRUCT_FREE_CONTENTS_ONLY(*pPduTypeDescType, pSendMsg);
    //  Release the memory allocated in ASN.1 PER encoding.
    // pu_freeContext (&g_stRrcEncodeCtxt);

    // Check
    if (RetVal.encoded > 0)
    {
        // Get the encoded octect num.s
        *pEncodedLen = (U16)((RetVal.encoded + 7) >> 3);
        debug_printf("Encode RRC Message SUCCESS! Channel:%d\n", pEncodeMsg->ucType);
    }
    else
    {
        *pEncodedLen = 0;
        LOG_WARN("Encode RRC Message FAIL! Channel=%d, Check the Message Setting!!!", pEncodeMsg->ucType);
        debug_printf("Encode RRC Message FAIL! Channel:%d, Check the Message Setting!!!\n", pEncodeMsg->ucType);
        return RRC_ERR_ASN1_ERR;
    }
    return RRC_SUCCESS;
}



